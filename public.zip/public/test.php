<?php

phpinfo();die;
$file = glob('./daigou/');

foreach ($file as $key => $value) {

}

